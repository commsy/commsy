<?php
/*
 * Copyright 2010 Dr. Iver Jackewitz
 *
 * configuration file for plugin commsy_auth
 */
$commsy_auth_commsy_url = 'http://commsy';
?>
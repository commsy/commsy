<?php
/* 
 * Copyright 2010 Edouard J. Simon
*/
/*
Plugin Name: CommSy Blog
Plugin URI: NONE
Description: 
Author: Edouard J. Simon
Version: 0.2
Author URI: NONE
*/


class commsy_blog {

  /**
   * @param array $user
   * @param array $blog
   *
   * @return array
   */
  public function createBlog($user, $blog) {

    try {
      if(!isset($user['login']) || empty($user['login'])
              || !isset($user['email']) || empty($user['email'])
              || !isset($blog['path']) || empty($blog['path'])
              || !isset($blog['title']) || empty($blog['title'])
              || !defined('DOMAIN_CURRENT_SITE')
              || !defined('PATH_CURRENT_SITE')
      ) {
        $vars = var_export(array('user' => $user, 'blog' => $blog, 'DOMAIN_CURRENT_SITE' => DOMAIN_CURRENT_SITE, 'PATH_CURRENT_SITE' => PATH_CURRENT_SITE), true);
        throw new Exception('Supplied data not valid:'.$vars);
      }

      $user_id = cs_update_user($user);
      $blog_id = wpmu_create_blog(DOMAIN_CURRENT_SITE, PATH_CURRENT_SITE.$blog['path'], $blog['title'], $user_id);

    } catch (Exception $e) {
      throw new SoapFault('createblog', 'Create Blog failed: '.$e->getMessage());
    }
    return array('user_id' => $user_id, 'blog_id' => $blog_id);
  }

  public function deleteBlog($blogId) {
    switch_to_blog($blogId);
    wpmu_delete_blog($blogId, true);
    restore_current_blog();
  }


  /**
   * @param array $post Data to insert
   * @param array $user Data to insert
   * @param int $blogId Data to insert
   * @param string $category Data to insert
   * @return int Id of Post or 0 on error
   */
  public function insertPost($post, $user, $blogId, $category) {
    try {
      if($blogId == 0) throw new Exception('Invalid Blog ID!');
      switch_to_blog($blogId);
      $catId = get_cat_ID($category);
      if($catId == 0) {
        include_once('wp-admin/includes/taxonomy.php');
        $catId = wp_create_category( $category );
      }
      $post['post_category'] = array($catId);
      $addUserToBlog = (false == get_user_by('login', $user['login']));
      $post['post_author'] = cs_update_user($user);
      if($addUserToBlog) add_user_to_blog($blogId, $post['post_author'], get_option('default_role'));

      $postId = wp_insert_post($post);
      restore_current_blog();
    } catch (Exception $e) {
      throw new SoapFault('insertpost', 'Insert Post failed: '.$e->getMessage());
    }
    return $postId;
  }


  /**
   * @param array $file
   * @param int $blogId
   *
   * @return string URL to file
   */
  public function insertFile($file, $blogId) {
    try {
      switch_to_blog($blogId);
      $uploadDir = wp_upload_dir();
      $blogDir = $uploadDir['path'].'/';
      if(file_exists($blogDir.$file['name'])) {
        $counter = 1;
        while(file_exists($blogDir.$counter.$file['name'])) $counter++;
        $file['name'] = $counter.$file['name'];
      }
      if(!file_put_contents($blogDir.$file['name'], base64_decode($file['data']))) {
        throw new Exception('copying of file '.$file['name'].' to '.$uploadDir['path'].'/'.$file['name'].' failed.');
      }
      restore_current_blog();
    } catch(Exception $e) {
      throw new SoapFault('file upload failed', $e->getMessage());
    }
    return $uploadDir['url'].'/'.$file['name'];
  }

  /**
   * @param int $postId
   * @param int $blogId
   * @return boolean
   */
  public function getPostExists($postId, $blogId) {
    switch_to_blog($blogId);
    $post = get_post($postId);
    restore_current_blog();
    return is_object($post);
  }

  /**
   * @return array
   */
  public function getSkins() {
    return get_themes();
  }

//  protected function createUser($user, $blogId=false) {
//
//    include_once('wp-includes/registration.php');
//
//    $userarray['user_login'] 	= $user['login'];
//    $userarray['user_pass'] 	= isset($user['password']) ? $user['password'] : uniqid();
//    $userarray['user_email'] 	= $user['email'];
//    if(isset($user['firstname']) && isset($user['lastname'])) {
//      $userarray['first_name'] 	= $user['firstname'];
//      $userarray['last_name'] 	= $user['lastname'];
//    }
//    $userarray['display_name'] = $user['login'];
//
//    if($id = username_exists($user['login'])) {
//      $userarray['ID'] = $id;
//      $result = wp_update_user($userarray);
//    } else {
//      $user_id = wp_insert_user($userarray);
//      if($user_id instanceof WP_Error) throw new Exception(var_export($user_id, true));
//      $userarray['ID'] = $user_id;
//      if($blogId) add_user_to_blog($blogId, $userarray['ID'], get_option('default_role'));
//    }
//    return $userarray['ID'];
//  }

  /**
   * @param string $name
   * @param string $value
   * @param int $blogId
   */
  public function insertOption($name, $value, $blogId) {
    switch_to_blog($blogId);
    add_option($name, $value);
    restore_current_blog();
  }

  /**
   * @param string $name
   * @param string $value
   * @param int $blogId
   */
  public function updateOption($name, $value, $blogId) {
    switch_to_blog($blogId);
    update_option($name, $value);
    restore_current_blog();
  }

  /**
   * @param string $name
   * @param int $blogId
   *
   * @return string Option value
   */
  public function getOption($name, $blogId) {
    switch_to_blog($blogId);
    $value = get_option($name);
    restore_current_blog();
    return $value;
  }

}


function commsy_soap() {

  ini_set('soap.wsdl_cache_enabled', 0);
  ini_set('include_path', ini_get('include_path').':'.dirname(__FILE__));
  if(isset($_GET['wsdl'])) {
    include_once('commsyblog.wsdl.php');
    exit;


  } else if(isset($_SERVER['HTTP_SOAPACTION'])) {
    $soap = new SoapServer('http://'.$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"]."?wsdl");
    $soap->setClass('commsy_blog');
    $soap->handle();
    exit;

  }
}
add_action('wp_loaded', 'commsy_soap');

?>

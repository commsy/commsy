ALTER TABLE /*_*/oauth_registered_consumer ADD COLUMN `oarc_callback_is_prefix` tinyblob NULL DEFAULT NULL;

ALTER TABLE `[COMMSY_CONTEXT_ID]_archive_backup` RENAME `[COMMSY_CONTEXT_ID]_archive`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_bot_passwords_backup` RENAME `[COMMSY_CONTEXT_ID]_bot_passwords`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_category_backup` RENAME `[COMMSY_CONTEXT_ID]_category`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_categorylinks_backup` RENAME `[COMMSY_CONTEXT_ID]_categorylinks`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_change_tag_backup` RENAME `[COMMSY_CONTEXT_ID]_change_tag`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_externallinks_backup` RENAME `[COMMSY_CONTEXT_ID]_externallinks`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_filearchive_backup` RENAME `[COMMSY_CONTEXT_ID]_filearchive`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_image_backup` RENAME `[COMMSY_CONTEXT_ID]_image`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_imagelinks_backup` RENAME `[COMMSY_CONTEXT_ID]_imagelinks`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_interwiki_backup` RENAME `[COMMSY_CONTEXT_ID]_interwiki`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_ipblocks_backup` RENAME `[COMMSY_CONTEXT_ID]_ipblocks`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_iwlinks_backup` RENAME `[COMMSY_CONTEXT_ID]_iwlinks`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_job_backup` RENAME `[COMMSY_CONTEXT_ID]_job`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_l10n_cache_backup` RENAME `[COMMSY_CONTEXT_ID]_l10n_cache`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_langlinks_backup` RENAME `[COMMSY_CONTEXT_ID]_langlinks`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_log_search_backup` RENAME `[COMMSY_CONTEXT_ID]_log_search`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_logging_backup` RENAME `[COMMSY_CONTEXT_ID]_logging`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_module_deps_backup` RENAME `[COMMSY_CONTEXT_ID]_module_deps`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_objectcache_backup` RENAME `[COMMSY_CONTEXT_ID]_objectcache`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_oldimage_backup` RENAME `[COMMSY_CONTEXT_ID]_oldimage`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_page_backup` RENAME `[COMMSY_CONTEXT_ID]_page`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_page_props_backup` RENAME `[COMMSY_CONTEXT_ID]_page_props`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_page_restrictions_backup` RENAME `[COMMSY_CONTEXT_ID]_page_restrictions`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_pagelinks_backup` RENAME `[COMMSY_CONTEXT_ID]_pagelinks`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_protected_titles_backup` RENAME `[COMMSY_CONTEXT_ID]_protected_titles`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_querycache_backup` RENAME `[COMMSY_CONTEXT_ID]_querycache`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_querycache_info_backup` RENAME `[COMMSY_CONTEXT_ID]_querycache_info`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_querycachetwo_backup` RENAME `[COMMSY_CONTEXT_ID]_querycachetwo`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_recentchanges_backup` RENAME `[COMMSY_CONTEXT_ID]_recentchanges`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_redirect_backup` RENAME `[COMMSY_CONTEXT_ID]_redirect`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_revision_backup` RENAME `[COMMSY_CONTEXT_ID]_revision`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_searchindex_backup` RENAME `[COMMSY_CONTEXT_ID]_searchindex`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_site_identifiers_backup` RENAME `[COMMSY_CONTEXT_ID]_site_identifiers`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_site_stats_backup` RENAME `[COMMSY_CONTEXT_ID]_site_stats`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_sites_backup` RENAME `[COMMSY_CONTEXT_ID]_sites`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_tag_summary_backup` RENAME `[COMMSY_CONTEXT_ID]_tag_summary`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_templatelinks_backup` RENAME `[COMMSY_CONTEXT_ID]_templatelinks`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_text_backup` RENAME `[COMMSY_CONTEXT_ID]_text`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_transcache_backup` RENAME `[COMMSY_CONTEXT_ID]_transcache`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_updatelog_backup` RENAME `[COMMSY_CONTEXT_ID]_updatelog`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_uploadstash_backup` RENAME `[COMMSY_CONTEXT_ID]_uploadstash`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_backup` RENAME `[COMMSY_CONTEXT_ID]_user`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_former_groups_backup` RENAME `[COMMSY_CONTEXT_ID]_user_former_groups`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_groups_backup` RENAME `[COMMSY_CONTEXT_ID]_user_groups`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_newtalk_backup` RENAME `[COMMSY_CONTEXT_ID]_user_newtalk`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_properties_backup` RENAME `[COMMSY_CONTEXT_ID]_user_properties`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_valid_tag_backup` RENAME `[COMMSY_CONTEXT_ID]_valid_tag`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_watchlist_backup` RENAME `[COMMSY_CONTEXT_ID]_watchlist`;
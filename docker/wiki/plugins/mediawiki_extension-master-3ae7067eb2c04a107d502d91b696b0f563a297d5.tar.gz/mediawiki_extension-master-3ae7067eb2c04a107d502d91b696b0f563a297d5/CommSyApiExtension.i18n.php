<?php
$messages = array();
$messages['en'] = array(
        'sampleapiextension-desc' => "CommSy API-Erweiterung zur Anbindung von Mediawiki an CommSy",
);
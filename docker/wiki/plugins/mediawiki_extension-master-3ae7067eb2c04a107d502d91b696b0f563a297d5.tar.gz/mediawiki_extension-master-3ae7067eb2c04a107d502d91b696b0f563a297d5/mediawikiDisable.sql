ALTER TABLE `[COMMSY_CONTEXT_ID]_archive` RENAME `[COMMSY_CONTEXT_ID]_archive_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_bot_passwords` RENAME `[COMMSY_CONTEXT_ID]_bot_passwords_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_category` RENAME `[COMMSY_CONTEXT_ID]_category_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_categorylinks` RENAME `[COMMSY_CONTEXT_ID]_categorylinks_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_change_tag` RENAME `[COMMSY_CONTEXT_ID]_change_tag_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_externallinks` RENAME `[COMMSY_CONTEXT_ID]_externallinks_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_filearchive` RENAME `[COMMSY_CONTEXT_ID]_filearchive_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_image` RENAME `[COMMSY_CONTEXT_ID]_image_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_imagelinks` RENAME `[COMMSY_CONTEXT_ID]_imagelinks_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_interwiki` RENAME `[COMMSY_CONTEXT_ID]_interwiki_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_ipblocks` RENAME `[COMMSY_CONTEXT_ID]_ipblocks_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_iwlinks` RENAME `[COMMSY_CONTEXT_ID]_iwlinks_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_job` RENAME `[COMMSY_CONTEXT_ID]_job_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_l10n_cache` RENAME `[COMMSY_CONTEXT_ID]_l10n_cache_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_langlinks` RENAME `[COMMSY_CONTEXT_ID]_langlinks_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_log_search` RENAME `[COMMSY_CONTEXT_ID]_log_search_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_logging` RENAME `[COMMSY_CONTEXT_ID]_logging_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_module_deps` RENAME `[COMMSY_CONTEXT_ID]_module_deps_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_objectcache` RENAME `[COMMSY_CONTEXT_ID]_objectcache_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_oldimage` RENAME `[COMMSY_CONTEXT_ID]_oldimage_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_page` RENAME `[COMMSY_CONTEXT_ID]_page_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_page_props` RENAME `[COMMSY_CONTEXT_ID]_page_props_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_page_restrictions` RENAME `[COMMSY_CONTEXT_ID]_page_restrictions_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_pagelinks` RENAME `[COMMSY_CONTEXT_ID]_pagelinks_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_protected_titles` RENAME `[COMMSY_CONTEXT_ID]_protected_titles_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_querycache` RENAME `[COMMSY_CONTEXT_ID]_querycache_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_querycache_info` RENAME `[COMMSY_CONTEXT_ID]_querycache_info_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_querycachetwo` RENAME `[COMMSY_CONTEXT_ID]_querycachetwo_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_recentchanges` RENAME `[COMMSY_CONTEXT_ID]_recentchanges_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_redirect` RENAME `[COMMSY_CONTEXT_ID]_redirect_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_revision` RENAME `[COMMSY_CONTEXT_ID]_revision_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_searchindex` RENAME `[COMMSY_CONTEXT_ID]_searchindex_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_site_identifiers` RENAME `[COMMSY_CONTEXT_ID]_site_identifiers_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_site_stats` RENAME `[COMMSY_CONTEXT_ID]_site_stats_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_sites` RENAME `[COMMSY_CONTEXT_ID]_sites_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_tag_summary` RENAME `[COMMSY_CONTEXT_ID]_tag_summary_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_templatelinks` RENAME `[COMMSY_CONTEXT_ID]_templatelinks_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_text` RENAME `[COMMSY_CONTEXT_ID]_text_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_transcache` RENAME `[COMMSY_CONTEXT_ID]_transcache_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_updatelog` RENAME `[COMMSY_CONTEXT_ID]_updatelog_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_uploadstash` RENAME `[COMMSY_CONTEXT_ID]_uploadstash_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user` RENAME `[COMMSY_CONTEXT_ID]_user_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_former_groups` RENAME `[COMMSY_CONTEXT_ID]_user_former_groups_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_groups` RENAME `[COMMSY_CONTEXT_ID]_user_groups_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_newtalk` RENAME `[COMMSY_CONTEXT_ID]_user_newtalk_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_user_properties` RENAME `[COMMSY_CONTEXT_ID]_user_properties_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_valid_tag` RENAME `[COMMSY_CONTEXT_ID]_valid_tag_backup`;
#
ALTER TABLE `[COMMSY_CONTEXT_ID]_watchlist` RENAME `[COMMSY_CONTEXT_ID]_watchlist_backup`;
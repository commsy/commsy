<?php

class CommSyHooks {
    
    public static function onArticlePageDataBefore( $article, $fields ) {
        if (isset($_GET['session-id'])) {
            global $wgUser;
            $sessionId = $_GET['session-id'];
            if (!$wgUser->isLoggedIn()) {
                $configuration = parse_ini_file(__DIR__.'/configuration.ini');
                ini_set("soap.wsdl_cache_enabled", 0);
                $soapClient = new SoapClient($configuration['commsyUrl'].$configuration['commsySoap'].'?wsdl=true');
                if ($soapClient->isSessionValid($sessionId)) {
                    $userId = $soapClient->getUserIdBySessionId($sessionId);
                    if ($userId) {
                        global $wgAuth;
                        if (!$wgAuth->userExists($userId)) {
                            $user = User::newFromName($userId);
                            $user->setEmail('');
                            $user->setRealName($userId);
                            $user->addToDatabase();
                            $user->setPassword($userId);
                            $user->saveSettings();
                        }
                        $userId = User::idFromName( $userId );
                        $wgUser->setID( $userId );
                        $wgUser->loadFromId();
                        $wgUser->setCookies();
                    }
                }
            }
        }
    }
    
}
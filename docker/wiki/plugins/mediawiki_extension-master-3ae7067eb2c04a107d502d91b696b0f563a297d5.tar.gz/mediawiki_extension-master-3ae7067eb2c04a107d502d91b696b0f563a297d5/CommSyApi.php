<?php
class CommSyApi extends ApiBase {

    protected $configuration;

    protected $function;

    protected $sessionId;

    protected $contextId;

    protected $deleteFlag;

    public function execute() {
        $this->configuration = parse_ini_file(__DIR__.'/configuration.ini');
        $this->function = $this->getMain()->getVal('function');
        $this->sessionId = $this->getMain()->getVal('session-id');
        $this->contextId = $this->getMain()->getVal('context-id');
        $this->deleteFlag = $this->getMain()->getVal('delete');

        if ($this->autenticateWithCommSy()) {
            if ($this->function == 'enablewiki') {
                if (!$this->isWikiEnabled()) {
                    if (!$this->existsWikiBackup()) {
                        if (!file_exists($this->configuration['mediawikiRoot'] . '/wikis')) {
                            mkdir($this->configuration['mediawikiRoot'] . '/wikis');
                        }
                        if (!file_exists($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId)) {
                            mkdir($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId);
                        }
                        copy(__DIR__ . '/LocalSettings.php-dist', $this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId . '/LocalSettings.php');

                        $localSettings = file_get_contents($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId . '/LocalSettings.php');
                        $localSettings = str_ireplace('[SITENAME]', 'CommSy - ' . $this->contextId, $localSettings);
                        $localSettings = str_ireplace('[SERVER]', $this->configuration['mediawikiUrl'], $localSettings);
                        $localSettings = str_ireplace('[UPLOAD_DIR]', $this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId . '/uploads', $localSettings);
                        $localSettings = str_ireplace('[COMMSY_CONTEXT_ID]', $this->contextId, $localSettings);
                        $localSettings = str_ireplace('[DB_SERVER]', $this->configuration['dbServer'], $localSettings);
                        $localSettings = str_ireplace('[DB_NAME]', $this->configuration['dbName'], $localSettings);
                        $localSettings = str_ireplace('[DB_USER]', $this->configuration['dbUser'], $localSettings);
                        $localSettings = str_ireplace('[DB_PASSWORD]', $this->configuration['dbPassword'], $localSettings);
                        file_put_contents($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId . '/LocalSettings.php', $localSettings);

                        mkdir($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId . '/uploads');

                        $database = wfGetDB(DB_MASTER);
                        $sql = file_get_contents(__DIR__ . '/mediawiki.sql');
                        $sql = str_ireplace('[COMMSY_CONTEXT_ID]', $this->contextId, $sql);
                        $sql = preg_replace('/\s+/S', " ", $sql);
                        $sqlArray = explode('#', $sql);

                        foreach ($sqlArray as $query) {
                            $database->query($query);
                        }
                        $this->getResult()->addValue(null, $this->getModuleName(), array('result' => 'wiki enabled'));
                    } else {
                        if (file_exists($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId.'_backup')) {
                            rename($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId.'_backup', $this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId);
                        }

                        $database = wfGetDB(DB_MASTER);
                        $sql = file_get_contents(__DIR__ . '/mediawikiEnable.sql');
                        $sql = str_ireplace('[COMMSY_CONTEXT_ID]', $this->contextId, $sql);
                        $sql = preg_replace('/\s+/S', " ", $sql);
                        $sqlArray = explode('#', $sql);

                        foreach ($sqlArray as $query) {
                            $database->query($query);
                        }
                        $this->getResult()->addValue(null, $this->getModuleName(), array('result' => 'wiki enabled'));
                    }
                } else {
                    $this->getResult()->addValue(null, $this->getModuleName(), array('error' => 'wiki is enabled'));
                }
            } else if ($this->function == 'disablewiki') {
                if ($this->isWikiEnabled()) {
                    if (!$this->deleteFlag) {
                        if (file_exists($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId)) {
                            rename($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId, $this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId.'_backup');
                        }

                        $database = wfGetDB(DB_MASTER);
                        $sql = file_get_contents(__DIR__ . '/mediawikiDisable.sql');
                        $sql = str_ireplace('[COMMSY_CONTEXT_ID]', $this->contextId, $sql);
                        $sql = preg_replace('/\s+/S', " ", $sql);
                        $sqlArray = explode('#', $sql);

                        foreach ($sqlArray as $query) {
                            $database->query($query);
                        }
                        $this->getResult()->addValue(null, $this->getModuleName(), array('result' => 'wiki disabled'));
                    } else {
                        if (file_exists($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId)) {
                            $this->rrmdir($this->configuration['mediawikiRoot'] . '/wikis/' . $this->contextId);
                        }

                        $database = wfGetDB(DB_MASTER);
                        $sql = file_get_contents(__DIR__ . '/mediawikiRemove.sql');
                        $sql = str_ireplace('[COMMSY_CONTEXT_ID]', $this->contextId, $sql);
                        $sql = preg_replace('/\s+/S', " ", $sql);
                        $sqlArray = explode('#', $sql);

                        foreach ($sqlArray as $query) {
                            $database->query($query);
                        }
                        $this->getResult()->addValue(null, $this->getModuleName(), array('result' => 'wiki removed'));
                    }
                } else {
                    $this->getResult()->addValue(null, $this->getModuleName(), array('error' => 'wiki is disabled'));
                }
            } else if ($this->function == 'iswikienabled') {
                if ($this->isWikiEnabled()) {
                    $this->getResult()->addValue(null, $this->getModuleName(), array('result' => 'wiki is enabled'));
                } else {
                    $this->getResult()->addValue(null, $this->getModuleName(), array('result' => 'wiki is disabled'));
                }
            } else {
                $this->getResult()->addValue(null, $this->getModuleName(), array('error' => 'select valid function ...'));
            }
        } else {
            $this->getResult()->addValue(null, $this->getModuleName(), array('result' => 'session id not authenticated'));
        }

        return true;
    }

    private function isWikiEnabled(){
        $wikiExists = true;
        if (!file_exists($this->configuration['mediawikiRoot'].'/wikis/' . $this->contextId)) {
            $wikiExists = false;
        }
        $database = wfGetDB( DB_MASTER );
        if(!$database->tableExists($this->contextId.'_sites')) {
            $wikiExists = false;
        }
        return $wikiExists;
    }

    private function existsWikiBackup(){
        $wikiExistsBackup = true;
        if (!file_exists($this->configuration['mediawikiRoot'].'/wikis/' . $this->contextId.'_backup')) {
            $wikiExistsBackup = false;
        }
        $database = wfGetDB( DB_MASTER );
        if(!$database->tableExists($this->contextId.'_sites_backup')) {
            $wikiExistsBackup = false;
        }
        return $wikiExistsBackup;
    }

    private function autenticateWithCommSy () {
        $result = false;

        if ($this->soapClient()->isSessionValid($this->sessionId)) {
            $result = true;
        }

        return $result;
    }

    private function soapClient () {
        return new SoapClient($this->configuration['commsyUrl'].$this->configuration['commsySoap'].'?wsdl=true');
    }

    private function rrmdir($dir) {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (is_dir($dir."/".$object))
                        $this->rrmdir($dir."/".$object);
                    else
                        unlink($dir."/".$object);
                }
            }
            rmdir($dir);
        }
    }

    /* --- API --- */

    // Description
    public function getDescription() {
         return 'CommSy API-extension';
     }

    // Face parameter.
    public function getAllowedParams() {
        return array_merge( parent::getAllowedParams(), array(
            'function' => array (
                ApiBase::PARAM_TYPE => 'string',
                ApiBase::PARAM_REQUIRED => true
            ),
            'session-id' => array (
                ApiBase::PARAM_TYPE => 'string',
                ApiBase::PARAM_REQUIRED => true
            ),
            'context-id' => array (
                ApiBase::PARAM_TYPE => 'string',
                ApiBase::PARAM_REQUIRED => true
            ),
            'delete' => array (
                ApiBase::PARAM_TYPE => 'string',
                ApiBase::PARAM_REQUIRED => false
            ),
        ) );
    }

    // Describe the parameter
    public function getParamDescription() {
        return array_merge( parent::getParamDescription(), array(
            'function' => 'Function to perform -> enableWiki, disableWiki, ...',
            'session-id' => 'CommSy session-id to authenticate with the CommSy-server.',
            'context-id' => 'CommSy context-id of the context (community-room, project-room) the wiki is used in.',
            'delete' => 'Flag to not disable but delete the wiki.'
        ) );
    }

     // Get examples
     public function getExamples() {
         return array(
             'api.php?action=commsy&function=enablewiki&session-id=...&context-id=...'
             => 'Enable a new wiki',
             'api.php?action=commsy&function=disablewiki&session-id=...&context-id=...'
             => 'Disable a wiki',
             'api.php?action=commsy&function=disablewiki&session-id=...&context-id=...&delete=true'
             => 'Delete a wiki',
             'api.php?action=commsy&function=iswikienabled&session-id=...&context-id=...'
             => 'Is wiki enabled?'
         );
    }
}

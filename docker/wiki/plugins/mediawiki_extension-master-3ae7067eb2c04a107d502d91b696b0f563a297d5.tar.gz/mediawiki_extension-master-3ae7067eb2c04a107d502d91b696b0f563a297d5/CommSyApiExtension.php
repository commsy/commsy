<?php
 
// Nehmen Sie Anerkennung für ihre Arbeit.
$wgExtensionCredits['api'][] = array(
 
   // Der vollständige Pfad und Dateiname von der Datei. Dies erlaubt MediaWiki
   // um die Unterversion Versionsnummer auf Spezial:Version anzuzeigen.
   'path' => __FILE__,
 
   // Der Name der Erweiterung, welcher auf Spezial:Version erscheint.
   'name' => 'CommSy API-Funktion',
 
   // Eine Beschreibung der Erweiterung, welche auf Spezial:Version erscheint.
   'description' => 'CommSy API-Erweiterung zur Anbindung von Mediawiki an CommSy',
 
   // Alternativ können Sie einen Nachrichtenschlüssel für die Beschreibung angeben.
   'descriptionmsg' => 'commsy-desc',
 
   // Die Version der Erweiterung, die auf Spezial:Version erscheint.
   // Dies kann eine Zahl oder ein String sein.
   'version' => 1, 
 
   // Ihr Name, welcher auf Spezial:Version erscheint.
   'author' => 'effective WEBWORK GmbH',
 
   // Die URL zu einer Wiki-Seite/Web-Seite mit Informationen über die Erweiterung,
   // die auf Spezial:Version erscheint.
   'url' => 'http://docs.commsy.net/Plugins/Mediawiki/Index.html',
 
);
 
// Map class name to filename for autoloading
$wgAutoloadClasses['CommSyApi'] = dirname( __FILE__ ) . '/CommSyApi.php';

// Map module name to class name
$wgAPIModules['commsy'] = 'CommSyApi';

// Load the internationalization file
$wgExtensionMessagesFiles['commsy'] = dirname( __FILE__ )  . '/CommSyApiExtension.i18n.php';

// Return true so that MediaWiki continues to load extensions.
return true;